package app.mustansar.recoverycenter.recovery_center;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
